import sys
import os
import json

script_dir = os.path.dirname(os.path.abspath(__file__))
try:
    file = sys.argv[1]
    filepath = os.path.join(script_dir, file)

    if file.count(".mtx") != True:
        print("Missing or wrong file extension")
        sys.exit(1)
except IndexError:
    print("Missing file")
    sys.exit(1)


def current():
    return lines[index]

with open(filepath, "r") as f:
    lines = f.readlines()
    collect = False
    ast = []
    index = 0

    while index < len(lines):
        line = lines[index].strip()

        if line.endswith("{"):
            name = line[:line.index("{")].strip()
            index += 1
            line = current()
            if line.count("file"):
                writer_file = line[line.index(":"):].strip()
                writer_file = writer_file.replace(": ", "")
                index += 2
                line = current()
                if line.count("code"):
                    code = []
                    index += 1
                    line = current()
                    while True:
                        code.append(line.strip())
                        index += 1
                        line = current()

                        if line.count("}"):
                            break
                    
                    ast.append({
                        "name": name,
                        "file": writer_file,
                        "code": code
                    })


        index += 1

with open("macros.json", "w") as file:
    json.dump(ast, file, indent=2)